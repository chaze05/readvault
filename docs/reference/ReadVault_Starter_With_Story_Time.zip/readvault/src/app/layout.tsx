import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ReadVault — Your Personal Library & Story Time",
  description: "A personal digital library for PDF books and illustrated storybooks.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
