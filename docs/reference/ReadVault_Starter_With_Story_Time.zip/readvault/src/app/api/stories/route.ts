import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function mapStory(row: Record<string, unknown>) {
  return {
    id: Number(row.id),
    title: String(row.title),
    storyType: String(row.story_type),
    sourceTitle: row.source_title ? String(row.source_title) : null,
    description: row.description ? String(row.description) : null,
    ageRange: row.age_range ? String(row.age_range) : null,
    language: String(row.language || "en"),
    coverImageUrl: row.cover_image_path ? `/api/stories/${Number(row.id)}/images?kind=cover` : null,
    status: String(row.status),
    pageCount: Number(row.page_count || 0),
    currentPage: Number(row.current_page || 1),
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at)
  };
}

export async function GET() {
  const rows = db.prepare(`
    SELECT s.*,
      (SELECT COUNT(*) FROM story_pages p WHERE p.story_id = s.id) AS page_count,
      COALESCE((SELECT current_page FROM story_progress rp WHERE rp.story_id = s.id), 1) AS current_page
    FROM stories s
    ORDER BY s.updated_at DESC, s.id DESC
  `).all() as Record<string, unknown>[];
  return NextResponse.json(rows.map(mapStory));
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const title = String(body.title || "").trim().slice(0, 160);
    const storyType = body.storyType === "movie_inspired" ? "movie_inspired" : body.storyType === "original" ? "original" : null;
    const sourceTitle = String(body.sourceTitle || "").trim().slice(0, 160) || null;
    const description = String(body.description || "").trim().slice(0, 1000) || null;
    const ageRange = String(body.ageRange || "").trim().slice(0, 40) || null;
    const language = String(body.language || "en").trim().slice(0, 12) || "en";
    const status = body.status === "published" ? "published" : "draft";
    const pages = Array.isArray(body.pages) ? body.pages : [];

    if (!title) return NextResponse.json({ error: "Please enter a story title." }, { status: 400 });
    if (!storyType) return NextResponse.json({ error: "Choose a valid story type." }, { status: 400 });
    if (storyType === "movie_inspired" && !sourceTitle) return NextResponse.json({ error: "Enter the movie or inspiration title." }, { status: 400 });
    if (pages.length > 100) return NextResponse.json({ error: "A story can have up to 100 pages." }, { status: 400 });

    const create = db.transaction(() => {
      const result = db.prepare(`
        INSERT INTO stories (title, story_type, source_title, description, age_range, language, status)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `).run(title, storyType, sourceTitle, description, ageRange, language, status);
      const storyId = Number(result.lastInsertRowid);
      const insertPage = db.prepare("INSERT INTO story_pages (story_id, page_number, content) VALUES (?, ?, ?)");
      pages.forEach((page: unknown, index: number) => {
        const content = String((page as { content?: unknown })?.content || "").trim().slice(0, 10000);
        if (content) insertPage.run(storyId, index + 1, content);
      });
      return storyId;
    });
    const id = create();
    return NextResponse.json({ id }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Unable to create this story." }, { status: 500 });
  }
}
