import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const storyId = Number(id);
  if (!db.prepare("SELECT id FROM stories WHERE id = ?").get(storyId)) return NextResponse.json({ error: "Story not found." }, { status: 404 });
  try {
    const body = await request.json();
    const content = String(body.content || "").trim().slice(0, 10000);
    if (!content) return NextResponse.json({ error: "Page text is required." }, { status: 400 });
    const max = db.prepare("SELECT COALESCE(MAX(page_number), 0) AS max FROM story_pages WHERE story_id = ?").get(storyId) as { max: number };
    const result = db.prepare("INSERT INTO story_pages (story_id, page_number, content) VALUES (?, ?, ?)").run(storyId, max.max + 1, content);
    db.prepare("UPDATE stories SET updated_at = CURRENT_TIMESTAMP WHERE id = ?").run(storyId);
    return NextResponse.json({ id: Number(result.lastInsertRowid), pageNumber: max.max + 1 }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Unable to add story page." }, { status: 500 });
  }
}
