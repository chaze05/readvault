import { NextRequest, NextResponse } from "next/server";
import fs from "node:fs";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const storyId = Number(id);
  if (!Number.isInteger(storyId) || storyId < 1) return NextResponse.json({ error: "Invalid story ID." }, { status: 400 });
  const row = db.prepare(`
    SELECT s.*,
      COALESCE((SELECT current_page FROM story_progress rp WHERE rp.story_id = s.id), 1) AS current_page
    FROM stories s WHERE s.id = ?
  `).get(storyId) as Record<string, unknown> | undefined;
  if (!row) return NextResponse.json({ error: "Story not found." }, { status: 404 });
  const pages = db.prepare("SELECT * FROM story_pages WHERE story_id = ? ORDER BY page_number").all(storyId) as Record<string, unknown>[];
  return NextResponse.json({
    id: Number(row.id), title: String(row.title), storyType: String(row.story_type),
    sourceTitle: row.source_title ? String(row.source_title) : null,
    description: row.description ? String(row.description) : null,
    ageRange: row.age_range ? String(row.age_range) : null,
    language: String(row.language || "en"), status: String(row.status),
    coverImageUrl: row.cover_image_path ? `/api/stories/${storyId}/images?kind=cover` : null,
    currentPage: Number(row.current_page || 1),
    pages: pages.map(page => ({
      id: Number(page.id), pageNumber: Number(page.page_number), content: String(page.content),
      imageUrl: page.image_path ? `/api/stories/${storyId}/images?pageId=${Number(page.id)}` : null,
      imageAlt: page.image_alt ? String(page.image_alt) : null
    })),
    createdAt: String(row.created_at), updatedAt: String(row.updated_at)
  });
}

export async function PATCH(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const storyId = Number(id);
  if (!Number.isInteger(storyId) || storyId < 1) return NextResponse.json({ error: "Invalid story ID." }, { status: 400 });
  const exists = db.prepare("SELECT id FROM stories WHERE id = ?").get(storyId);
  if (!exists) return NextResponse.json({ error: "Story not found." }, { status: 404 });
  try {
    const body = await request.json();
    const title = String(body.title || "").trim().slice(0, 160);
    const storyType = body.storyType === "movie_inspired" ? "movie_inspired" : body.storyType === "original" ? "original" : null;
    const sourceTitle = String(body.sourceTitle || "").trim().slice(0, 160) || null;
    const description = String(body.description || "").trim().slice(0, 1000) || null;
    const ageRange = String(body.ageRange || "").trim().slice(0, 40) || null;
    const status = body.status === "published" ? "published" : "draft";
    if (!title || !storyType) return NextResponse.json({ error: "A title and valid story type are required." }, { status: 400 });
    if (storyType === "movie_inspired" && !sourceTitle) return NextResponse.json({ error: "Movie or inspiration title is required." }, { status: 400 });
    db.prepare(`UPDATE stories SET title = ?, story_type = ?, source_title = ?, description = ?, age_range = ?, status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`)
      .run(title, storyType, sourceTitle, description, ageRange, status, storyId);

    if (Array.isArray(body.pages)) {
      if (body.pages.length > 100) return NextResponse.json({ error: "A story can have up to 100 pages." }, { status: 400 });
      const updatePages = db.transaction(() => {
        const existing = db.prepare("SELECT id, image_path, image_alt FROM story_pages WHERE story_id = ?").all(storyId) as
          { id: number; image_path?: string; image_alt?: string }[];
        const byId = new Map(existing.map(page => [page.id, page]));
        db.prepare("DELETE FROM story_pages WHERE story_id = ?").run(storyId);
        const insert = db.prepare("INSERT INTO story_pages (story_id, page_number, content, image_path, image_alt) VALUES (?, ?, ?, ?, ?)");
        body.pages.forEach((page: unknown, index: number) => {
          const item = page as { id?: number; content?: unknown };
          const content = String(item?.content || "").trim().slice(0, 10000);
          if (content) {
            const oldPage = item.id ? byId.get(Number(item.id)) : undefined;
            insert.run(storyId, index + 1, content, oldPage?.image_path || null, oldPage?.image_alt || null);
          }
        });
      });
      updatePages();
    }
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Unable to update this story." }, { status: 500 });
  }
}

export async function DELETE(_request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const storyId = Number(id);
  const row = db.prepare("SELECT cover_image_path FROM stories WHERE id = ?").get(storyId) as { cover_image_path?: string } | undefined;
  if (!row) return NextResponse.json({ error: "Story not found." }, { status: 404 });
  const images = db.prepare("SELECT image_path FROM story_pages WHERE story_id = ?").all(storyId) as { image_path?: string }[];
  db.prepare("DELETE FROM stories WHERE id = ?").run(storyId);
  for (const filePath of [row.cover_image_path, ...images.map(image => image.image_path)]) {
    if (filePath && fs.existsSync(filePath)) fs.unlinkSync(filePath);
  }
  return NextResponse.json({ success: true });
}
