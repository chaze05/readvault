import { NextRequest, NextResponse } from "next/server";
import fs from "node:fs";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function PATCH(request: NextRequest, context: { params: Promise<{ id: string; pageId: string }> }) {
  const { id, pageId } = await context.params;
  const storyId = Number(id);
  const pageNumber = Number(pageId);
  const row = db.prepare("SELECT id FROM story_pages WHERE id = ? AND story_id = ?").get(pageNumber, storyId);
  if (!row) return NextResponse.json({ error: "Story page not found." }, { status: 404 });
  try {
    const body = await request.json();
    const content = String(body.content || "").trim().slice(0, 10000);
    if (!content) return NextResponse.json({ error: "Page text cannot be empty." }, { status: 400 });
    db.prepare("UPDATE story_pages SET content = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?").run(content, pageNumber);
    db.prepare("UPDATE stories SET updated_at = CURRENT_TIMESTAMP WHERE id = ?").run(storyId);
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Unable to update page." }, { status: 500 });
  }
}

export async function DELETE(_request: Request, context: { params: Promise<{ id: string; pageId: string }> }) {
  const { id, pageId } = await context.params;
  const storyId = Number(id);
  const pageNumber = Number(pageId);
  const row = db.prepare("SELECT image_path FROM story_pages WHERE id = ? AND story_id = ?").get(pageNumber, storyId) as { image_path?: string } | undefined;
  if (!row) return NextResponse.json({ error: "Story page not found." }, { status: 404 });
  db.prepare("DELETE FROM story_pages WHERE id = ?").run(pageNumber);
  const remaining = db.prepare("SELECT id FROM story_pages WHERE story_id = ? ORDER BY page_number").all(storyId) as { id: number }[];
  const reorder = db.prepare("UPDATE story_pages SET page_number = ? WHERE id = ?");
  const tx = db.transaction(() => remaining.forEach((page, index) => reorder.run(index + 1, page.id)));
  tx();
  if (row.image_path && fs.existsSync(row.image_path)) fs.unlinkSync(row.image_path);
  db.prepare("UPDATE stories SET updated_at = CURRENT_TIMESTAMP WHERE id = ?").run(storyId);
  return NextResponse.json({ success: true });
}
