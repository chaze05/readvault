"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { ArrowLeft, ArrowRight, BookOpen, Pause, Volume2, Pencil, Printer } from "lucide-react";
import type { Story } from "@/lib/types";

export function StoryReader({ storyId, initialStory }: { storyId: number; initialStory: Story }) {
  const [story, setStory] = useState(initialStory);
  const [pageIndex, setPageIndex] = useState(Math.min(Math.max(0, (initialStory.pages?.length || 1) - 1), Math.max(0, (initialStory.currentPage || 1) - 1)));
  const [speaking, setSpeaking] = useState(false);
  const pages = story.pages || [];
  const page = pages[pageIndex];

  useEffect(() => {
    const currentPage = pageIndex + 1;
    const timer = window.setTimeout(() => {
      void fetch(`/api/stories/${storyId}/progress`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ currentPage }) });
    }, 400);
    return () => window.clearTimeout(timer);
  }, [pageIndex, storyId]);

  useEffect(() => () => { if (typeof window !== "undefined" && "speechSynthesis" in window) window.speechSynthesis.cancel(); }, []);

  function speak() {
    if (!page || !("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(page.content);
    utterance.lang = story.language === "en" ? "en-US" : story.language;
    utterance.onend = () => setSpeaking(false);
    utterance.onerror = () => setSpeaking(false);
    window.speechSynthesis.speak(utterance);
    setSpeaking(true);
  }
  function stop() {
    if ("speechSynthesis" in window) window.speechSynthesis.cancel();
    setSpeaking(false);
  }

  if (!pages.length) return <main className="min-h-screen bg-[#f8f6fa] p-8"><div className="mx-auto max-w-xl rounded-2xl bg-white p-8 text-center"><BookOpen className="mx-auto mb-3 text-[#7954a5]" size={30}/><h1 className="text-xl font-bold">{story.title}</h1><p className="text-sm text-muted">This story does not have any pages yet.</p><Link href={`/story-time/${storyId}/edit`} className="text-sm font-semibold text-[#7954a5]">Add story pages</Link></div></main>;

  return <main className="min-h-screen bg-[#f8f6fa]"><div className="screen-story"><header className="sticky top-0 z-10 flex items-center justify-between border-b border-[#e9e2ef] bg-white/95 px-4 py-3 backdrop-blur"><Link href="/story-time" className="inline-flex items-center gap-2 text-sm font-semibold text-ink no-underline"><ArrowLeft size={17}/> Story Time</Link><div className="hidden text-center sm:block"><p className="m-0 text-sm font-bold">{story.title}</p><p className="m-0 text-[10px] text-muted">Page {pageIndex+1} of {pages.length}</p></div><div className="flex items-center gap-2"><button onClick={() => window.print()} className="inline-flex items-center gap-2 rounded-lg border border-line px-3 py-2 text-xs font-semibold text-muted"><Printer size={14}/> <span className="hidden sm:inline">Print / Save PDF</span></button><Link href={`/story-time/${storyId}/edit`} className="inline-flex items-center gap-2 rounded-lg border border-line px-3 py-2 text-xs font-semibold text-muted no-underline"><Pencil size={14}/> Edit</Link></div></header>
    <div className="mx-auto flex min-h-[calc(100vh-60px)] max-w-4xl flex-col items-center justify-center px-4 py-8"><div className="mb-4 w-full max-w-2xl text-center"><p className="mb-1 text-[10px] font-bold uppercase tracking-[.2em] text-[#7954a5]">{story.storyType === "original" ? "An original ReadVault story" : "An unofficial, independently written movie-inspired story"}</p><h1 className="m-0 font-serif text-2xl font-bold text-ink sm:text-3xl">{story.title}</h1></div>
      <article className="w-full max-w-2xl overflow-hidden rounded-[26px] border border-[#e9e2ef] bg-white shadow-[0_18px_55px_rgba(55,38,72,.08)]">{page.imageUrl ? <div className="flex max-h-[48vh] justify-center bg-[#f4eff8]"><img src={page.imageUrl} alt={page.imageAlt || `Illustration for ${story.title}, page ${pageIndex+1}`} className="max-h-[48vh] w-full object-contain"/></div> : <div className="grid h-48 place-items-center bg-gradient-to-br from-[#eee5f6] to-[#e1eef0] text-[#7954a5]"><SparklesFallback/></div>}
        <div className="px-6 py-7 sm:px-12 sm:py-10"><p className="mb-5 text-center text-[10px] font-bold uppercase tracking-[.2em] text-[#a18bb7]">Page {pageIndex+1}</p><p className="m-0 whitespace-pre-wrap text-center font-serif text-lg leading-[2] text-[#393341] sm:text-xl">{page.content}</p></div>
      </article>
      <div className="mt-5 flex w-full max-w-2xl items-center justify-between gap-3"><button onClick={() => { stop(); setPageIndex(i => Math.max(0,i-1)); }} disabled={pageIndex===0} className="inline-flex items-center gap-2 rounded-xl border border-[#e1d8e9] bg-white px-4 py-3 text-sm font-semibold text-[#685778] disabled:opacity-40"><ArrowLeft size={16}/> Previous</button><div className="flex items-center gap-2"><button onClick={speaking ? stop : speak} className="inline-flex items-center gap-2 rounded-xl bg-[#eee5f6] px-3 py-3 text-sm font-semibold text-[#7954a5]" title="Read this page aloud">{speaking ? <Pause size={16}/> : <Volume2 size={16}/>}<span className="hidden sm:inline">{speaking ? "Pause / stop" : "Read aloud"}</span></button><span className="text-xs font-semibold text-muted">{pageIndex+1}/{pages.length}</span></div><button onClick={() => { stop(); setPageIndex(i => Math.min(pages.length-1,i+1)); }} disabled={pageIndex===pages.length-1} className="inline-flex items-center gap-2 rounded-xl bg-[#7954a5] px-4 py-3 text-sm font-semibold text-white disabled:opacity-40">Next <ArrowRight size={16}/></button></div>
      <div className="mt-4 h-1.5 w-full max-w-2xl overflow-hidden rounded-full bg-[#e9e2ef]"><div className="h-full rounded-full bg-[#9b7ac0] transition-all" style={{width:`${((pageIndex+1)/pages.length)*100}%`}}/></div>
      <p className="mt-4 text-center text-[11px] text-muted">ReadVault Story Time · Read together, imagine together.</p>
    </div></div>
    <section className="print-story">
      <div className="print-cover"><h1>{story.title}</h1><p>{story.description}</p></div>
      {pages.map((item, index) => <article className="print-page" key={item.id}>
        {item.imageUrl && <img src={item.imageUrl} alt={item.imageAlt || `Illustration for page ${index+1}`}/>}
        <p className="print-page-number">Page {index+1}</p>
        <p className="print-page-text">{item.content}</p>
      </article>)}
    </section>
  </main>;
}

function SparklesFallback() {
  return <div className="text-center"><span className="text-5xl">✨</span><p className="mt-3 text-xs font-semibold uppercase tracking-widest">Your illustration goes here</p></div>;
}
