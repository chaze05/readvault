import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function PATCH(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const storyId = Number(id);
  if (!db.prepare("SELECT id FROM stories WHERE id = ?").get(storyId)) return NextResponse.json({ error: "Story not found." }, { status: 404 });
  const body = await request.json();
  const page = Math.max(1, Math.floor(Number(body.currentPage) || 1));
  const count = db.prepare("SELECT COUNT(*) AS count FROM story_pages WHERE story_id = ?").get(storyId) as { count: number };
  const boundedPage = Math.min(page, Math.max(1, count.count));
  db.prepare(`
    INSERT INTO story_progress (story_id, current_page, last_read_at, updated_at)
    VALUES (?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    ON CONFLICT(story_id) DO UPDATE SET current_page = excluded.current_page, last_read_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
  `).run(storyId, boundedPage);
  return NextResponse.json({ success: true, currentPage: boundedPage });
}
