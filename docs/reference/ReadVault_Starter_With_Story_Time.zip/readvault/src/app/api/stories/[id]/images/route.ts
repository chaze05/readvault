import { NextRequest, NextResponse } from "next/server";
import fs from "node:fs";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const allowedTypes: Record<string, string> = {
  "image/jpeg": ".jpg",
  "image/png": ".png",
  "image/webp": ".webp"
};

export async function POST(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const storyId = Number(id);
  const story = db.prepare("SELECT id, cover_image_path FROM stories WHERE id = ?").get(storyId) as { id: number; cover_image_path?: string } | undefined;
  if (!story) return NextResponse.json({ error: "Story not found." }, { status: 404 });
  try {
    const form = await request.formData();
    const file = form.get("file");
    const pageId = Number(form.get("pageId") || 0);
    const alt = String(form.get("alt") || "").trim().slice(0, 300);
    if (!(file instanceof File) || file.size === 0) return NextResponse.json({ error: "Choose an image to upload." }, { status: 400 });
    const extension = allowedTypes[file.type];
    if (!extension) return NextResponse.json({ error: "Use a JPG, PNG, or WebP image." }, { status: 400 });
    if (file.size > 8 * 1024 * 1024) return NextResponse.json({ error: "Images must be 8 MB or smaller." }, { status: 400 });
    if (pageId && !db.prepare("SELECT id FROM story_pages WHERE id = ? AND story_id = ?").get(pageId, storyId)) {
      return NextResponse.json({ error: "Story page not found." }, { status: 404 });
    }
    const bytes = Buffer.from(await file.arrayBuffer());
    const isJpeg = bytes.length > 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff;
    const isPng = bytes.length > 8 && bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]));
    const isWebp = bytes.length > 12 && bytes.toString("ascii", 0, 4) === "RIFF" && bytes.toString("ascii", 8, 12) === "WEBP";
    if ((file.type === "image/jpeg" && !isJpeg) || (file.type === "image/png" && !isPng) || (file.type === "image/webp" && !isWebp)) {
      return NextResponse.json({ error: "The selected file does not appear to be a valid image." }, { status: 400 });
    }
    const dir = path.join(process.cwd(), "data", "story-images");
    fs.mkdirSync(dir, { recursive: true });
    const filePath = path.join(dir, `${randomUUID()}${extension}`);
    fs.writeFileSync(filePath, bytes);
    if (pageId) {
      const old = db.prepare("SELECT image_path FROM story_pages WHERE id = ?").get(pageId) as { image_path?: string } | undefined;
      db.prepare("UPDATE story_pages SET image_path = ?, image_alt = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?").run(filePath, alt || null, pageId);
      if (old?.image_path && fs.existsSync(old.image_path)) fs.unlinkSync(old.image_path);
    } else {
      db.prepare("UPDATE stories SET cover_image_path = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?").run(filePath, storyId);
      if (story.cover_image_path && fs.existsSync(story.cover_image_path)) fs.unlinkSync(story.cover_image_path);
    }
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Unable to save this image." }, { status: 500 });
  }
}

export async function GET(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const storyId = Number(id);
  const url = new URL(request.url);
  const pageId = Number(url.searchParams.get("pageId") || 0);
  const isCover = url.searchParams.get("kind") === "cover" || !pageId;
  const row = isCover
    ? db.prepare("SELECT cover_image_path AS image_path FROM stories WHERE id = ?").get(storyId) as { image_path?: string } | undefined
    : db.prepare("SELECT image_path FROM story_pages WHERE id = ? AND story_id = ?").get(pageId, storyId) as { image_path?: string } | undefined;
  if (!row?.image_path || !fs.existsSync(row.image_path)) return NextResponse.json({ error: "Image not found." }, { status: 404 });
  const extension = path.extname(row.image_path).toLowerCase();
  const contentType = extension === ".png" ? "image/png" : extension === ".webp" ? "image/webp" : "image/jpeg";
  return new NextResponse(fs.readFileSync(row.image_path), { headers: { "Content-Type": contentType, "Cache-Control": "private, no-store" } });
}
