# ReadVault

A local-first personal PDF library built with Next.js, TypeScript, SQLite, and local file storage.

## Requirements

- Node.js 22 LTS (22.13+ recommended)
- npm
- Windows, macOS, or Linux

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000.

The SQLite database is created automatically at `data/readvault.db`. Uploaded PDFs are stored in `data/uploads/`. Story illustrations are stored in `data/story-images/`.

## Current functionality

- Responsive library dashboard
- Search and category filtering
- Upload PDF files
- Local SQLite metadata storage
- Local PDF file storage
- Browser-based PDF viewing
- Reading progress updates
- Delete books\n- Story Time: create original and movie-inspired stories\n- Story page editor with cover and page illustration uploads\n- Page-by-page story reader with saved reading progress\n- Browser read-aloud using built-in speech synthesis\n- Print / Save as PDF from the story reader

## Important deployment note

This starter is intended for local development on your own computer. The SQLite database and uploaded PDFs live on the local filesystem. Do not deploy this exact storage configuration to Vercel and expect persistent storage.

Before public or multi-device deployment, migrate the repository implementation to Supabase PostgreSQL and Supabase Storage (or another persistent database/object-storage provider). Keep uploaded files private and serve them through authenticated, short-lived access.

## Project structure

- `src/app`: routes and pages
- `src/components`: UI components
- `src/lib`: SQLite data access and helpers
- `data`: local database and uploads (ignored by Git)


## Story Time

Open **Story Time** from the sidebar to create illustrated storybooks.

- Create original stories or independently written movie-inspired summaries/adventures.
- Add multiple editable pages.
- Upload your own cover and page illustrations (JPG, PNG, WebP; up to 8 MB each).
- Read one page at a time and save reading progress automatically.
- Use the browser's built-in read-aloud feature where supported.
- Use **Print / Save PDF** in the reader to print or save a copy as PDF.

Story Time works locally without paid AI or image APIs. The MVP includes an original story starter, a movie-inspired writing outline, and image uploads for illustrations you create or have permission to use. Automatic AI image generation is not enabled in this build: a truly zero-subscription in-app generator would require a compatible local image model and suitable computer hardware (for example, a locally installed Stable Diffusion/ComfyUI setup). The app is structured so that a local generator can be added later without depending on a paid API.

### Copyright and child-safety note

Movie-inspired stories must use original wording and should be brief summaries or new adventures based on broad themes. Do not copy scripts, dialogue, complete books, official movie artwork, logos, or protected character designs. Story Time is a private, parent-managed feature; it does not include public sharing or child profiles.

### Local storage

Story records are stored in SQLite (`data/readvault.db`). Story images are stored in `data/story-images/`. Back up both the database and image directory. The app is intended for local use until authentication and private cloud storage are implemented.
