import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { StoryReader } from "@/components/story-reader";
import type { Story } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export default async function ReadStoryPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const storyId = Number(id);
  if (!Number.isInteger(storyId) || storyId < 1) notFound();
  const row = db.prepare(`
    SELECT s.*,
      COALESCE((SELECT current_page FROM story_progress rp WHERE rp.story_id = s.id), 1) AS current_page
    FROM stories s WHERE s.id = ?
  `).get(storyId) as Record<string, unknown> | undefined;
  if (!row) { notFound(); throw new Error("Story not found."); }
  const pages = db.prepare("SELECT * FROM story_pages WHERE story_id = ? ORDER BY page_number").all(storyId) as Record<string, unknown>[];
  const story: Story = {
    id: storyId,
    title: String(row.title),
    storyType: String(row.story_type) as Story["storyType"],
    sourceTitle: row.source_title ? String(row.source_title) : null,
    description: row.description ? String(row.description) : null,
    ageRange: row.age_range ? String(row.age_range) : null,
    language: String(row.language || "en"),
    coverImageUrl: row.cover_image_path ? `/api/stories/${storyId}/images?kind=cover` : null,
    status: String(row.status) as Story["status"],
    pageCount: pages.length,
    currentPage: Number(row.current_page || 1),
    pages: pages.map(page => ({
      id: Number(page.id),
      pageNumber: Number(page.page_number),
      content: String(page.content),
      imageUrl: page.image_path ? `/api/stories/${storyId}/images?pageId=${Number(page.id)}` : null,
      imageAlt: page.image_alt ? String(page.image_alt) : null
    })),
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at)
  };
  return <StoryReader storyId={storyId} initialStory={story} />;
}
