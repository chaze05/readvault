export type BookStatus = "not_started" | "reading" | "completed";

export type Book = {
  id: number;
  title: string;
  author: string;
  category: string;
  description: string | null;
  fileName: string | null;
  hasFile: boolean;
  totalPages: number;
  currentPage: number;
  status: BookStatus;
  coverColor: string;
  createdAt: string;
  updatedAt: string;
};

export type CreateBookInput = {
  title: string;
  author: string;
  category: string;
};


export type StoryType = "original" | "movie_inspired";
export type StoryStatus = "draft" | "published";

export type StoryPage = {
  id: number;
  pageNumber: number;
  content: string;
  imageUrl: string | null;
  imageAlt: string | null;
};

export type Story = {
  id: number;
  title: string;
  storyType: StoryType;
  sourceTitle: string | null;
  description: string | null;
  ageRange: string | null;
  language: string;
  coverImageUrl: string | null;
  status: StoryStatus;
  pageCount: number;
  currentPage: number;
  pages?: StoryPage[];
  createdAt: string;
  updatedAt: string;
};
