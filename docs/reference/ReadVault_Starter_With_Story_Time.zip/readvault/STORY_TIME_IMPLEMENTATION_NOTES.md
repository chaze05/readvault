# Story Time implementation notes

## Implemented in this starter

- Added `Story Time` to the desktop sidebar and mobile header.
- Added original and movie-inspired story types.
- Added a starter story for original writing and an outline for movie-inspired writing.
- Added editable story metadata and multi-page story editor.
- Added page reorder controls and page deletion.
- Added local cover and page illustration uploads (JPG, PNG, WebP; maximum 8 MB each).
- Added server-side image signature checks, safe generated filenames, and local storage in `data/story-images/`.
- Added page-by-page story reader with saved reading position.
- Added browser speech synthesis read-aloud when supported.
- Added full-story print layout so the browser can print or save the entire story as PDF.
- Added SQLite tables for stories, pages, and reading progress.
- Added API routes for story CRUD, page creation/update/deletion, images, and progress.

## Deliberately not included

- No paid AI text or image API.
- No automatic AI image generation in this build. To keep the app at a zero subscription cost, this requires the user to install and run a local image-generation model and provide a compatible local integration (e.g. ComfyUI). The rest of Story Time works without it.
- No cloud storage, user accounts, public sharing, or child profiles.

## Local data

- SQLite database: `data/readvault.db`
- PDF uploads: `data/uploads/`
- Story images: `data/story-images/`

Back up the database and both upload directories together.

## Validation status

The starter's dependencies could not be installed in the build environment because `npm install` timed out. TypeScript syntax was inspected with the globally available compiler, but a complete type-check, Next.js production build, and browser test have not been completed. Run `npm install`, `npm run lint`, and `npm run build` on the development machine and fix any reported issues before relying on the app.
