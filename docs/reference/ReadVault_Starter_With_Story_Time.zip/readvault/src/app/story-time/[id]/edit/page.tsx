import { StoryEditor } from "@/components/story-editor";

export default async function EditStoryPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <StoryEditor storyId={Number(id)} />;
}
